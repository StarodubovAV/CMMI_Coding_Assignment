# Detect_vessels_in_marina > 2025-07-28 7:18pm
https://universe.roboflow.com/start-project/detect_vessels_in_marina-2xemd

Provided by a Roboflow user
License: MIT

