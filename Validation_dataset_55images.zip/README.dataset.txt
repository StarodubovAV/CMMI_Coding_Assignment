# Ayia Napa Marina Boats > 2025-07-23 6:39pm
https://universe.roboflow.com/start-project/ayia-napa-marina-boats-em66u

Provided by a Roboflow user
License: MIT

